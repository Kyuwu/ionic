﻿namespace O2GOBackEnd.Models.Resources
{
    public class FromToInputModel
    {
        public DateTime From { get; set; }

        public DateTime To { get; set; }
    }
}
