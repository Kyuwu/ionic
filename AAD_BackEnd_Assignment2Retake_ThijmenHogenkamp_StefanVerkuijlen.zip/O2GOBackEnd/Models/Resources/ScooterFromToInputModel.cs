﻿namespace O2GOBackEnd.Models.Resources
{
    public class ScooterFromToInputModel
    {
        public Scooter Scooter { get; set; }

        public DateTime From { get; set; }

        public DateTime To { get; set; }
    }
}
